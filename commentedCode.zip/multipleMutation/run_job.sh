
for a in 1. 1.1 1.5 2.; do
  for b in 0.25 0.5 0.75 1; do
    density=$a move_rate=$b sbatch --output=out/${a}_${b}.out --job-name=alida_${a}_${b} slurm.sb
    echo 'running: density,' ${a} ' move_rate, ' ${b} 
  done
done



