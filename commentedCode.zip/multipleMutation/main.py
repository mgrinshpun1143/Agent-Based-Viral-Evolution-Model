import random
import numpy as np
# import matplotlib.pyplot as plt
import pandas as pd
import sys

from Field import Field
from Agent import Agent

"""
This function creates agents for the simulation

Args:
    numberAgents (int): How many agents are created
    n (int): size of the world
    m (int): size of the world
    populationR (list(agent)): list of agents who have the status removed
    populationI (list(agent)): list of agents who have the status infected
    populationS (list(agent)): list of agents who have the status susceptible
    populationWhole (list(agent)): list of all agents
    moveRate (float): a probability if the agent moves or not
    maskProbability (float): a probability how fast he will get infected
    span (int): how many field the agent can move from his startlocation
    virusTypes (list(int)): which kind of virus exists
    virusTypesRate (list(float)): infectionRate of each virus

Returns:
    -
"""
def createAgents(numberAgents, n, m, populationR, populationI, populationS, populationWhole, moveRate,
                 maskProbability, span, virusTypes, virusTypesRate, infectability):
    for i in range(numberAgents):
        posN = random.randint(0, n - 1)
        posM = random.randint(0, m - 1)
        name = "Agent_" + str(i)
        startLocation = [posN, posM]
        if i < 10:
            # virusTyp = random.randint(1, len(virusTypes) - 1)
            virusTyp = 1
            agentX = Agent(idAgent=name, location=[posN, posM], moveRate=moveRate, status="infected", daysInStatus=0,
                           infectability=infectability, startLocation=startLocation, mask=maskProbability, span=span,
                           virusType=virusTyp, virusTypesRate=virusTypesRate[virusTyp])
            populationI.append(agentX)
            populationWhole.append(agentX)
            addToStatisitcList(agentX, virusTyp)
        else:
            agentX = Agent(idAgent=name, location=[posN, posM], moveRate=moveRate, status="susceptible",
                           daysInStatus=0,
                           infectability=infectability, startLocation=startLocation, mask=maskProbability, span=span,
                           virusType=0, virusTypesRate=virusTypesRate[0])
            populationWhole.append(agentX)
            populationS.append(agentX)


"""
This function creates the world for the simulation. A world consits
of fields. On each field agents are placed.

Args:
    n (int): size of the world
    m (int): size of the world
    listAgents (list(agent)): list of all agents
    
Returns:
    world ([field,field]): an numpy array which consits of fields
"""
def initWorld(n, m, listAgents):
    # Create np array
    world = np.array([[Field("none", 0, []) for i in range(n)] for j in range(m)], dtype=object)

    # Set each field a type
    for row in world:
        for cell in row:
            fieldType = random.randint(0, 1)
            if fieldType == 0:
                cell.type = "outside"
            else:
                cell.type = "inside"

    # Go through the list of agents and place them on their start position
    for currAgent in listAgents:
        pos = currAgent.location
        (world[pos[0]][pos[1]]).count = (world[pos[0]][pos[1]]).count + 1
        (world[pos[0]][pos[1]]).listAgent.append(currAgent)

    return world


"""
This function checks if the agent is allowed to go to the next field 
because there is a span defined how far away the agent can go 
from his start position.

Args:
    world ([field,field]): the world for the simulation
    startLocation ([int, int]): the startLocation of the agent
    span (int): how many fields the agent can move from his start location in all directions
    newLocation ([int, int]): the new location which the agent would get
    
Returns:
    Bool: if the agent can move to the new location or not
"""
def legalSpan(world, startLocation, span, newLocation):
    fields = calculateSpan(world, startLocation, span)
    rowFields = fields[0]
    columnFields = fields[1]

    newN = newLocation[0]
    newM = newLocation[1]

    if newN in rowFields:
        if newM in columnFields:
            return True
    return False


"""
This function calculates all fields which the agent is allowed to move depending on the span

Args:
    world ([field,field]): the world for the simulation
    startLocation ([int, int]): the startLocation of the agent
    span (int): how many fields the agent can move from his start location in all directions
    

Returns:
    rowFields (list[int]): which rows the agent can move to
    columnFields (list[int]): which columns the agent can move to
"""
def calculateSpan(world, startLocation, span):
    worldDim = np.shape(world)
    n = worldDim[0]
    m = worldDim[1]

    # the most far away location the agent is allowed to visit
    maxLocN1 = startLocation[0] + span  # right
    maxLocM1 = startLocation[1] + span  # down
    maxLocN2 = startLocation[0] - span  # up
    maxLocM2 = startLocation[1] - span  # left

    minN = startLocation[0]
    minM = startLocation[1]

    # need flags to see if the agent would go out of the array because the world is considered as a thorax
    jumpN1 = False
    jumpN2 = False
    jumpM1 = False
    jumpM2 = False

    columnFields = [startLocation[1]]
    rowFields = [startLocation[0]]

    if (maxLocN1 > worldDim[0] - 1):
        maxLocN1 = maxLocN1 - n
        jumpN1 = True
    if (maxLocM1 > worldDim[1] - 1):
        maxLocM1 = maxLocM1 - m
        jumpM1 = True
    if (maxLocN2 < 0):
        maxLocN2 = maxLocN2 + n  # +1
        jumpN2 = True
    if (maxLocM2 < 0):
        maxLocM2 = maxLocM2 + m
        jumpM2 = True

    if not jumpN1 and not jumpN2:
        for i in range(maxLocN2, maxLocN1 + 1):
            # rowFields = rowFields.append(i)
            rowFields.append(i)
    elif jumpN1 and not jumpN2:
        # N1
        for i in range(0, maxLocN1 + 1):
            rowFields.append(i)
        for i in range(minN, n):
            rowFields.append(i)
        # N2
        for i in range(maxLocN2, minN):
            rowFields.append(i)
    elif not jumpN1 and jumpN2:
        # N1
        for i in range(minN, maxLocN1 + 1):
            rowFields.append(i)
        # N2
        for i in range(0, minN):
            rowFields.append(i)
        for i in range(maxLocN2, n):
            rowFields.append(i)
    elif jumpN2 and jumpN1:
        # N1
        for i in range(0, maxLocN1 + 1):
            rowFields.append(i)
        for i in range(minN, n):
            rowFields.append(i)
            # N2
        for i in range(0, minN):
            rowFields.append(i)
        for i in range(maxLocN2, n):
            rowFields.append(i)

    if not jumpM1 and not jumpM2:
        for i in range(maxLocM2, maxLocM1 + 1):
            columnFields.append(i)
    elif jumpM1 and not jumpM2:
        # M1
        for i in range(0, maxLocM1 + 1):
            columnFields.append(i)
        for i in range(minM, m):
            columnFields.append(i)
        # M2
        for i in range(maxLocM2, minM):
            columnFields.append(i)
    elif not jumpM1 and jumpM2:
        # M1
        for i in range(minM, maxLocM1 + 1):
            columnFields.append(i)
        # M2
        for i in range(0, minM):
            columnFields.append(i)
        for i in range(maxLocM2, m):
            columnFields.append(i)
    elif jumpM2 and jumpM1:
        # M1
        for i in range(0, maxLocM1 + 1):
            columnFields.append(i)
        for i in range(minM, m):
            columnFields.append(i)
            # M2
        for i in range(0, minM):
            columnFields.append(i)
        for i in range(maxLocM2, m):
            columnFields.append(i)

    return rowFields, columnFields


"""
This function calculates the new position for an agent

Args:
    direction (int): the direction in which the agent want to go next 
        0 = up-left, 1 = up, 2 = up-right, 3 = left, 4 = right, 5 = down-left, 6 = down, 7 = down-right
    world ([field,field]): the world for the simulation
    location ([int, int]): the current location of the agent    

Returns:
    newLoc ([int, int]): the new location for the agent
"""
def newPos(direction, world, location):
    # current location
    posN = location[0]
    posM = location[1]

    # dim of World
    worldDim = np.shape(world)
    n = worldDim[0] - 1
    m = worldDim[1] - 1

    newLoc = [posN, posM]

    # Up Left
    if direction == 0:
        if posN == 0 and posM == 0:
            newLoc[0] = n
            newLoc[1] = m
        elif posN == 0:
            newLoc[0] = n
            newLoc[1] = location[1] - 1
        elif posM == 0:
            newLoc[0] = location[0] - 1
            newLoc[1] = m
        else:
            newLoc[0] = location[0] - 1
            newLoc[1] = location[1] - 1
    # Up
    elif direction == 1:
        if posN == 0:
            newLoc[0] = n
        else:
            newLoc[0] = location[0] - 1
    # Up right
    elif direction == 2:
        if posN == 0 and posM == m:
            newLoc[0] = n
            newLoc[1] = 0
        elif posN == 0:
            newLoc[0] = n
            newLoc[1] = location[1] + 1
        elif posM == m:
            newLoc[0] = location[0] - 1
            newLoc[1] = 0
        else:
            newLoc[0] = location[0] - 1
            newLoc[1] = location[1] + 1

    elif direction == 3:
        if posM == 0:
            newLoc[1] = m
        else:
            newLoc[1] = location[1] - 1

    # Right
    elif direction == 4:
        if posM == m:
            newLoc[1] = 0
        else:
            newLoc[1] = location[1] + 1


    # Down left
    elif direction == 5:
        if posN == n and posM == 0:
            newLoc[0] = 0
            newLoc[1] = m
        elif posN == n:
            newLoc[0] = 0
            newLoc[1] = location[1] - 1
        elif posM == 0:
            newLoc[0] = location[0] + 1
            newLoc[1] = m
        else:
            newLoc[0] = location[0] + 1
            newLoc[1] = location[1] - 1

    # Down
    elif direction == 6:
        if posN == n:
            newLoc[0] = 0
        else:
            newLoc[0] = location[0] + 1

    # Down right
    elif direction == 7:
        if posN == n and posM == m:
            newLoc[0] = 0
            newLoc[1] = 0
        elif posN == n:
            newLoc[0] = 0
            newLoc[1] = location[1] + 1
        elif posM == m:
            newLoc[0] = location[0] + 1
            newLoc[1] = 0
        else:
            newLoc[0] = location[0] + 1
            newLoc[1] = location[1] + 1

    return newLoc


"""
This function moves the agent on the field

Args:
    direction (int): the direction in which the agent want to go next 
        0 = up-left, 1 = up, 2 = up-right, 3 = left, 4 = right, 5 = down-left, 6 = down, 7 = down-right
    world ([field,field]): the world for the simulation
    location ([int, int]): the current location of the agent  
    currAgent (Agent): the agent which will moved in the world  

Returns:
    newLoc ([int, int]): the new location for the agent
"""
def move(direction, world, location, currAgent):
    # current location
    posN = location[0]
    posM = location[1]

    # dim of World
    worldDim = np.shape(world)
    n = worldDim[0] - 1
    m = worldDim[1] - 1

    # currentPos decrement
    (world[posN][posM]).count = (world[posN][posM]).count - 1
    (world[posN][posM]).listAgent.remove(currAgent)

    newLoc = newPos(direction, world, location)
    # legalMove = legalSpan(world, currAgent.startLocation, span, newLoc)
    # print(legalMove)
    # list = calculateSpan(world, currAgent.startLocation, 3)  # spannweite

    legalMove = True
    if legalMove:
        # Top Left
        if direction == 0:
            if posN == 0 and posM == 0:
                (world[n][m]).count = (world[n][m]).count + 1
                location[0] = n
                location[1] = m
                (world[n][m]).listAgent.append(currAgent)
            elif posN == 0:  # erste zeile
                (world[n][posM - 1]).count = (world[n][posM - 1]).count + 1
                location[0] = n
                location[1] = location[1] - 1
                (world[n][posM - 1]).listAgent.append(currAgent)
            elif posM == 0:  # erste spalte
                (world[posN - 1][m]).count = (world[posN - 1][m]).count + 1
                location[0] = location[0] - 1
                location[1] = m
                (world[posN - 1][m]).listAgent.append(currAgent)
            else:
                (world[posN - 1][posM - 1]).count = (world[posN - 1][posM - 1]).count + 1
                location[0] = location[0] - 1
                location[1] = location[1] - 1
                (world[posN - 1][posM - 1]).listAgent.append(currAgent)

        # Top
        elif direction == 1:
            if posN == 0:
                (world[n][posM]).count = (world[n][posM]).count + 1
                location[0] = n
                (world[n][posM]).listAgent.append(currAgent)
            else:
                (world[posN - 1][posM]).count = (world[posN - 1][posM]).count + 1
                location[0] = location[0] - 1
                (world[posN - 1][posM]).listAgent.append(currAgent)
        # Top right
        elif direction == 2:
            if posN == 0 and posM == m:
                (world[n][0]).count = (world[n][0]).count + 1
                location[0] = n
                location[1] = 0
                (world[n][0]).listAgent.append(currAgent)
            elif posN == 0:
                (world[n][posM + 1]).count = (world[n][posM + 1]).count + 1
                location[0] = n
                location[1] = location[1] + 1
                (world[n][posM + 1]).listAgent.append(currAgent)
            elif posM == m:
                (world[posN - 1][0]).count = (world[posN - 1][0]).count + 1
                location[0] = location[0] - 1
                location[1] = 0
                (world[posN - 1][0]).listAgent.append(currAgent)
            else:
                (world[posN - 1][posM + 1]).count = (world[posN - 1][posM + 1]).count + 1
                location[0] = location[0] - 1
                location[1] = location[1] + 1
                (world[posN - 1][posM + 1]).listAgent.append(currAgent)

        elif direction == 3:
            if posM == 0:
                (world[posN][m]).count = (world[posN][m]).count + 1
                location[1] = m
                (world[posN][m]).listAgent.append(currAgent)
            else:
                (world[posN][posM - 1]).count = (world[posN][posM - 1]).count + 1
                location[1] = location[1] - 1
                (world[posN][posM - 1]).listAgent.append(currAgent)

        # Right
        elif direction == 4:
            if posM == m:
                (world[posN][0]).count = (world[posN][0]).count + 1
                location[1] = 0
                (world[posN][0]).listAgent.append(currAgent)
            else:
                (world[posN][posM + 1]).count = (world[posN][posM + 1]).count + 1
                location[1] = location[1] + 1
                (world[posN][posM + 1]).listAgent.append(currAgent)


        # Bottom left
        elif direction == 5:
            if posN == n and posM == 0:
                (world[0][m]).count = (world[0][m]).count + 1
                location[0] = 0
                location[1] = m
                (world[0][m]).listAgent.append(currAgent)
            elif posN == n:
                (world[0][posM - 1]).count = (world[0][posM - 1]).count + 1
                location[0] = 0
                location[1] = location[1] - 1
                (world[0][posM - 1]).listAgent.append(currAgent)
            elif posM == 0:
                (world[posN + 1][m]).count = (world[posN + 1][m]).count + 1
                location[0] = location[0] + 1
                location[1] = m
                (world[posN + 1][m]).listAgent.append(currAgent)
            else:
                (world[posN + 1][posM - 1]).count = (world[posN + 1][posM - 1]).count + 1
                location[0] = location[0] + 1
                location[1] = location[1] - 1
                (world[posN + 1][posM - 1]).listAgent.append(currAgent)

        # Bottom
        elif direction == 6:
            if posN == n:
                (world[0][posM]).count = (world[0][posM]).count + 1
                location[0] = 0
                (world[0][posM]).listAgent.append(currAgent)
            else:
                (world[posN + 1][posM]).count = (world[posN + 1][posM]).count + 1
                location[0] = location[0] + 1
                (world[posN + 1][posM]).listAgent.append(currAgent)

        # Bottom right
        elif direction == 7:
            if posN == n and posM == m:
                (world[0][0]).count = (world[0][0]).count + 1
                location[0] = 0
                location[1] = 0
                (world[0][0]).listAgent.append(currAgent)
            elif posN == n:
                (world[0][posM + 1]).count = (world[0][posM + 1]).count + 1
                location[0] = 0
                location[1] = location[1] + 1
                (world[0][posM + 1]).listAgent.append(currAgent)
            elif posM == m:
                (world[posN + 1][0]).count = (world[posN + 1][0]).count + 1
                location[0] = location[0] + 1
                location[1] = 0
                (world[posN + 1][0]).listAgent.append(currAgent)
            else:
                (world[posN + 1][posM + 1]).count = (world[posN + 1][posM + 1]).count + 1
                location[0] = location[0] + 1
                location[1] = location[1] + 1
                (world[posN + 1][posM + 1]).listAgent.append(currAgent)

    newLoc = [location[0], location[1]]
    return [world, location, newLoc]

"""
This function updates the parameters of the agent. An agent will never be susceptible and is only 5 days infected

Args: 
    currAgent (Agent): the agent which will be updated
    populationS (list[Agent]): the list contains all agents who has the status infected
    populationI (list[Agent]): the list contains all agents who has the status susceptible
    populationR (list[Agent]): the list contains all agents who has the status removed

Returns:
    [currAgent, populationS, populationI, populationR]
"""
def updateHealth(currAgent, populationS, populationI, populationR):
    currAgent.daysInStatus = currAgent.daysInStatus + 1

    if currAgent.status == "infected" and currAgent.daysInStatus >= 5:
        currAgent.status = "removed"
        currAgent.daysInStatus = 0
        populationI.remove(currAgent)
        populationR.append(currAgent)
    elif currAgent.status == "removed" and currAgent.daysInStatus >= 900000000:
        currAgent.status = "susceptible"
        currAgent.daysInStatus = 0
        populationS.append(currAgent)
        populationR.remove(currAgent)

    return [currAgent, populationS, populationI, populationR]


"""
This function calculates the mutation which the agent will get with a certain probability

Args: 
    virusType (int): the current virustype the agent has
    mutationRate (float): a probability if the agent gets a new mutation or the same
    
Returns:
    newVirusType (int)
"""
def mutateVirus(virusType, mutationRate):
    newVirusType = virusType
    if random.random() < mutationRate:
        newVirusType = min(10, max(1, virusType + (random.randint(0, 1) * 2 - 1)))
    return newVirusType


"""
This function adds agent to a list depending on which virustype he has in order to 
have statistic information

Args: 
    agent (Agent): the current agent
    virusType (int): the current virustype

Returns:
    -
"""
def addToStatisitcList(agent, virusType):
    if virusType == 1 and (agent.idAgent not in totalM1):
        totalM1.append(agent.idAgent)
    elif virusType == 2 and (agent.idAgent not in totalM2):
        totalM2.append(agent.idAgent)
    elif virusType == 3 and (agent.idAgent not in totalM3):
        totalM3.append(agent.idAgent)
    elif virusType == 4 and (agent.idAgent not in totalM4):
        totalM4.append(agent.idAgent)
    elif virusType == 5 and (agent.idAgent not in totalM5):
        totalM5.append(agent.idAgent)
    elif virusType == 6 and (agent.idAgent not in totalM6):
        totalM6.append(agent.idAgent)
    elif virusType == 7 and (agent.idAgent not in totalM7):
        totalM7.append(agent.idAgent)
    elif virusType == 8 and (agent.idAgent not in totalM8):
        totalM8.append(agent.idAgent)
    elif virusType == 9 and (agent.idAgent not in totalM9):
        totalM9.append(agent.idAgent)
    elif virusType == 10 and (agent.idAgent not in totalM10):
        totalM10.append(agent.idAgent)

"""
This function infect agent. If an agent gets infected depend on:
    virusTypesRate, infectionFactor, infectability of an agent, if agent wears a mask or not

Args: 
    listAgents (list(agent)): list of all agents
    populationS (list[Agent]): the list contains all agents who has the status infected
    populationI (list[Agent]): the list contains all agents who has the status susceptible
    populationR (list[Agent]): the list contains all agents who has the status removed
    infectionFactor (double): if the field is inside or outside
    virusTypes (list(int)): which kind of virus exists
    virusTypesRate (list(float)): infectionRate of each virus
    mutationRate (float): a probability if the agent gets a new mutation of the virus or not
    
Returns:
    [listAgent, populationS, populationI, populationR]
"""
def infectPeople(listAgent, populationS, populationI, populationR, infectionFactor, virusTypes, virusTypesRate,
                 mutationRate):
    numberInfectedAgents = 0

    listMutation = []
    listInfectedPeople = []
    listNotInfectedPeople = []

    for i in range(len(virusTypes)):
        listMutation.append(0)

    #create two list: one list of all infected agents on the field and one list for all uninfected agents on the fiel
    for currAgent in listAgent:
        if currAgent.status == "infected":
            numberInfectedAgents = numberInfectedAgents + 1
            mutation = currAgent.virusType
            listMutation[mutation] = listMutation[mutation] + 1
            listInfectedPeople.append(currAgent)
        else:
            listNotInfectedPeople.append(currAgent)

    #go through each infected agent and try to infect an unifected agent
    if numberInfectedAgents >= 1:
        for currInfectedAgent in listInfectedPeople:
            for currNotInfectedAgent in listNotInfectedPeople:
                if currNotInfectedAgent.status == "susceptible":
                    if random.random() < currInfectedAgent.virusTypesRate * infectionFactor * currNotInfectedAgent.infectability * currNotInfectedAgent.mask:
                        currNotInfectedAgent.status = "infected"
                        virusType = mutateVirus(currInfectedAgent.virusType, mutationRate)
                        currNotInfectedAgent.virusType = virusType
                        currNotInfectedAgent.virusTypesRate = virusTypesRate[virusType]
                        currNotInfectedAgent.daysInStatus = 0
                        populationS.remove(currNotInfectedAgent)
                        populationI.append(currNotInfectedAgent)

                        addToStatisitcList(currNotInfectedAgent, virusType)

    return [listAgent, populationS, populationI, populationR]


"""
This function print the world. It shows how many agents are on one field

Args: 
    world ([field,field]): an numpy array which consits of fields

Returns:
    arr
"""
def printWorld(world):
    worldDim = np.shape(world)
    arr = [[0 for x in range(worldDim[0])] for y in range(worldDim[1])]
    i = 0
    j = 0

    for row in world:
        for cell in row:
            arr[i][j] = cell.count
            j = j + 1
        i = i + 1
        j = 0

    return arr


"""
This function creates for each mutation a numpy array in order to print later an image with matplotlib.

Args: 
    world ([field,field]): an numpy array which consits of fields

Returns:
    arr, arrMut1, arrMut2, arrMut3, arrMut4, arrMut5, arrMut6, arrMut7, arrMut8, arrMut9, arrMut10
"""
def printInfected(world):
    worldDim = np.shape(world)
    arr = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    i = 0
    j = 0

    arrMut1 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut2 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut3 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut4 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut5 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut6 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut7 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut8 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut9 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])
    arrMut10 = np.array([[0 for i in range(worldDim[0])] for j in range(worldDim[1])])

    numberInfected = 0
    numMut1 = 0
    numMut2 = 0
    numMut3 = 0
    numMut4 = 0
    numMut5 = 0
    numMut6 = 0
    numMut7 = 0
    numMut8 = 0
    numMut9 = 0
    numMut10 = 0

    for row in world:
        for cell in row:
            for currAgent in cell.listAgent:
                if currAgent.status == "infected":
                    numberInfected = numberInfected + 1

                    if currAgent.virusType == 1:
                        numMut1 = numMut1 + 1
                    elif currAgent.virusType == 2:
                        numMut2 = numMut2 + 1
                    elif currAgent.virusType == 3:
                        numMut3 = numMut3 + 1
                    elif currAgent.virusType == 4:
                        numMut4 = numMut4 + 1
                    elif currAgent.virusType == 5:
                        numMut5 = numMut5 + 1
                    elif currAgent.virusType == 6:
                        numMut6 = numMut6 + 1
                    elif currAgent.virusType == 7:
                        numMut7 = numMut7 + 1
                    elif currAgent.virusType == 8:
                        numMut8 = numMut8 + 1
                    elif currAgent.virusType == 9:
                        numMut9 = numMut9 + 1
                    elif currAgent.virusType == 10:
                        numMut10 = numMut10 + 1

            arr[i][j] = numberInfected
            arrMut1[i][j] = numMut1
            arrMut2[i][j] = numMut2
            arrMut3[i][j] = numMut3
            arrMut4[i][j] = numMut4
            arrMut5[i][j] = numMut5
            arrMut6[i][j] = numMut6
            arrMut7[i][j] = numMut7
            arrMut8[i][j] = numMut8
            arrMut9[i][j] = numMut9
            arrMut10[i][j] = numMut10

            j = j + 1
            numberInfected = 0
            numMut1 = 0
            numMut2 = 0
            numMut3 = 0
            numMut4 = 0
            numMut5 = 0
            numMut6 = 0
            numMut7 = 0
            numMut8 = 0
            numMut9 = 0
            numMut10 = 0

        i = i + 1
        j = 0

    return arr, arrMut1, arrMut2, arrMut3, arrMut4, arrMut5, arrMut6, arrMut7, arrMut8, arrMut9, arrMut10

"""
This function creates a list which shows how many agents are infected with a specifiv virustype

Args: 
    populationI (list(agent)): list of agents who have the status infected

Returns:
    res (list(int)): a list how many people are infected with a specifc virustype
"""
def getNumberOfInfectedMutation(populationI):
    res = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for agent in populationI:
        if agent.virusType == 1:
            res[1] = res[1] + 1
        elif agent.virusType == 2:
            res[2] = res[2] + 1
        elif agent.virusType == 3:
            res[3] = res[3] + 1
        elif agent.virusType == 4:
            res[4] = res[4] + 1
        elif agent.virusType == 5:
            res[5] = res[5] + 1
        elif agent.virusType == 6:
            res[6] = res[6] + 1
        elif agent.virusType == 7:
            res[7] = res[7] + 1
        elif agent.virusType == 8:
            res[8] = res[8] + 1
        elif agent.virusType == 9:
            res[9] = res[9] + 1
        elif agent.virusType == 10:
            res[10] = res[10] + 1
    return res

"""
This function creates a list which shows how many agents are infected with a specifiv virustype

Args: 
    world ([field,field]): the world for the simulation
    periods (int): how long a simulation takes
    populationWhole (list(agent)): list of all agents
    populationR (list(agent)): list of agents who have the status removed
    populationI (list(agent)): list of agents who have the status infected
    populationS (list(agent)): list of agents who have the status susceptible
    infectionFactorInside (float): a probability how fast he will get infected
    infectionFactorOutside (float): a probability how fast he will get infected
    virusTypes (list(int)): which kind of virus exists
    virusTypesRate (list(float)): infectionRate of each virus
    mutationRate (float): a probability if the agent gets a new mutation or the same

Returns:
    [datasetSusceptible, datasetInfected, datasetRemoved, datasetMut1, datasetMut2, datasetMut3, datasetMut4,
            datasetMut5, datasetMut6, datasetMut7, datasetMut8, datasetMut9, datasetMut10]
"""
def simulate(world, periods, populationWhole, populationS, populationI, populationR,
             infectionFactorInside, infectionFactorOutside, virusTypes, virusTypesRate, mutationRate):
    for i in range(periods):
        # update dataset to create a plot
        datasetSusceptible.append(len(populationS))
        datasetInfected.append(len(populationI))
        datasetRemoved.append(len(populationR))

        # for data analysis
        listNumberInfectedMutation = getNumberOfInfectedMutation(populationI)
        datasetMut1.append(listNumberInfectedMutation[1])
        datasetMut2.append(listNumberInfectedMutation[2])
        datasetMut3.append(listNumberInfectedMutation[3])
        datasetMut4.append(listNumberInfectedMutation[4])
        datasetMut5.append(listNumberInfectedMutation[5])
        datasetMut6.append(listNumberInfectedMutation[6])
        datasetMut7.append(listNumberInfectedMutation[7])
        datasetMut8.append(listNumberInfectedMutation[8])
        datasetMut9.append(listNumberInfectedMutation[9])
        datasetMut10.append(listNumberInfectedMutation[10])

        for currAgent in populationWhole:
            # direction for agent
            direction = random.randint(0, 7)
            currLocation = currAgent.location


            currAgent, populationS, populationI, populationR = updateHealth(currAgent, populationS, populationI,
                                                                            populationR)

            newLoc = newPos(direction, world, currLocation)
            legalMove = legalSpan(world, currAgent.startLocation, span, newLoc)

            # legalMove = True
            if legalMove:
                if random.random() < currAgent.moveRate:
                    world, currLocation, newLoc = move(direction, world, currLocation, currAgent)

        for row in world:
            for cell in row:
                if cell.count >= 2:
                    infectionFactor = 0
                    if cell.type == "inside":
                        infectionFactor = infectionFactorInside
                    elif cell.type == "outside":
                        infectionFactor = infectionFactorOutside
                    listAgent, populationS, populationI, populationR = infectPeople(cell.listAgent, populationS,
                                                                                    populationI, populationR,
                                                                                    infectionFactor,
                                                                                    virusTypes, virusTypesRate,
                                                                                    mutationRate)

    return [datasetSusceptible, datasetInfected, datasetRemoved, datasetMut1, datasetMut2, datasetMut3, datasetMut4,
            datasetMut5, datasetMut6, datasetMut7, datasetMut8, datasetMut9, datasetMut10]


if __name__ == '__main__':
    status = ["susceptible", "infected", "removed"]


    numberAgent = 5000
    infectionFactorInside = 1  #if the field is inside: the probability to get an infection is more likely if the field is inside
    infectionFactorOutside = 1  #if the field is outside: the probability to get an infection is less likely if the field is outside
    mutationRate = 0.1 #value between 0 and 1, is a probabilty if the agent gets the same mutation or another one
    infectabilityOfAgent = 1


    simulations = 10
    periods = 500
    maskProbability = 1
    moveRate = float(sys.argv[2])

    r0 = 1
    selectionStrength = float(sys.argv[1])
    density = r0 / (10*(0.1**selectionStrength))
    n = int(np.sqrt(numberAgent/density))
    m = int(np.sqrt(numberAgent/density))
    span = 2*n

    virusTypes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    virusTypesRate = [(0.1*x)**selectionStrength for x in range(11)]
    #virusTypesRate = [0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0]
    x = [i for i in range(periods)]
    xStr = ["Period" + str(i) for i in range(periods)]


    dfMut1 = pd.DataFrame(columns=xStr)
    dfMut2 = pd.DataFrame(columns=xStr)
    dfMut3 = pd.DataFrame(columns=xStr)
    dfMut4 = pd.DataFrame(columns=xStr)
    dfMut5 = pd.DataFrame(columns=xStr)
    dfMut6 = pd.DataFrame(columns=xStr)
    dfMut7 = pd.DataFrame(columns=xStr)
    dfMut8 = pd.DataFrame(columns=xStr)
    dfMut9 = pd.DataFrame(columns=xStr)
    dfMut10 = pd.DataFrame(columns=xStr)

    statM1 = []
    statM2 = []
    statM3 = []
    statM4 = []
    statM5 = []
    statM6 = []
    statM7 = []
    statM8 = []
    statM9 = []
    statM10 = []

    for i in range(simulations):
        # how many agents in total had which kind of mutation
        totalM1 = []
        totalM2 = []
        totalM3 = []
        totalM4 = []
        totalM5 = []
        totalM6 = []
        totalM7 = []
        totalM8 = []
        totalM9 = []
        totalM10 = []

        # list of all agents, s = susceptible, i = infected, r = removed
        populationS = []
        populationI = []
        populationR = []
        populationWhole = []

        # for statisicts
        datasetInfected = []
        datasetSusceptible = []
        datasetRemoved = []

        # which agent is infected
        datasetMut1 = []
        datasetMut2 = []
        datasetMut3 = []
        datasetMut4 = []
        datasetMut5 = []
        datasetMut6 = []
        datasetMut7 = []
        datasetMut8 = []
        datasetMut9 = []
        datasetMut10 = []

        createAgents(numberAgent, n, m, populationR, populationI, populationS, populationWhole, moveRate,
                     maskProbability, span, virusTypes, virusTypesRate, infectabilityOfAgent)

        myWorld = initWorld(n, m, listAgents=populationWhole)
        datasetSusceptible, datasetInfected, datasetRemoved, datasetMut1, datasetMut2, datasetMut3, datasetMut4, datasetMut5, datasetMut6, datasetMut7, datasetMut8, datasetMut9, datasetMut10 = simulate(
            myWorld, periods, populationWhole,
            populationS,
            populationI, populationR,
            infectionFactorInside,
            infectionFactorOutside, virusTypes, virusTypesRate, mutationRate)
        statM1.append(len(totalM1))
        statM2.append(len(totalM2))
        statM3.append(len(totalM3))
        statM4.append(len(totalM4))
        statM5.append(len(totalM5))
        statM6.append(len(totalM6))
        statM7.append(len(totalM7))
        statM8.append(len(totalM8))
        statM9.append(len(totalM9))
        statM10.append(len(totalM10))

        dfMut1.loc[len(dfMut1)] = datasetMut1
        dfMut2.loc[len(dfMut1)] = datasetMut2
        dfMut3.loc[len(dfMut1)] = datasetMut3
        dfMut4.loc[len(dfMut1)] = datasetMut4
        dfMut5.loc[len(dfMut1)] = datasetMut5
        dfMut6.loc[len(dfMut1)] = datasetMut6
        dfMut7.loc[len(dfMut1)] = datasetMut7
        dfMut8.loc[len(dfMut1)] = datasetMut8
        dfMut9.loc[len(dfMut1)] = datasetMut9
        dfMut10.loc[len(dfMut1)] = datasetMut10


    dict = {'M1': statM1, 'M2': statM2, 'M3': statM3, 'M4': statM4, 'M5': statM5, 'M6': statM6, 'M7': statM7,
            'M8': statM8, 'M9': statM9, 'M10': statM10}
    df = pd.DataFrame(dict)
    df.columns = ["Mutation1", "Mutation2", "Mutation3", "Mutation4", "Mutation5", "Mutation6", "Mutation7",
                  "Mutation8", "Mutation9", "Mutation10"]

    suffix = f"density_{density}_moveRate_{moveRate}_selectionStrength_{selectionStrength}"
    df.to_csv("data/statisticWhole_" + suffix + ".txt", index=None, sep=',')
    dfMut1.to_csv("data/statisticMutation1_" + suffix + ".txt", index=None, sep=',')
    dfMut2.to_csv("data/statisticMutation2_" + suffix + ".txt", index=None, sep=',')
    dfMut3.to_csv("data/statisticMutation3_" + suffix + ".txt", index=None, sep=',')
    dfMut4.to_csv("data/statisticMutation4_" + suffix + ".txt", index=None, sep=',')
    dfMut5.to_csv("data/statisticMutation5_" + suffix + ".txt", index=None, sep=',')
    dfMut6.to_csv("data/statisticMutation6_" + suffix + ".txt", index=None, sep=',')
    dfMut7.to_csv("data/statisticMutation7_" + suffix + ".txt", index=None, sep=',')
    dfMut8.to_csv("data/statisticMutation8_" + suffix + ".txt", index=None, sep=',')
    dfMut9.to_csv("data/statisticMutation9_" + suffix + ".txt", index=None, sep=',')
    dfMut10.to_csv("data/statisticMutation10_" + suffix + ".txt", index=None, sep=',')


    TextFile = open("data/dataSettings_" + suffix + ".txt", 'w')
    TextFile.writelines("simulations, " + str(simulations) + "\n")
    TextFile.writelines("periods, " + str(periods) + "\n")
    TextFile.writelines("n, " + str(n) + "\n")
    TextFile.writelines("m, " + str(m) + "\n")
    TextFile.writelines("span, " + str(span) + "\n")
    TextFile.writelines("infectionFactorInside, " + str(infectionFactorInside) + "\n")
    TextFile.writelines("infectionFactorOutside, " + str(infectionFactorOutside) + "\n")
    TextFile.writelines("mutationRate, " + str(mutationRate) + "\n")
    TextFile.writelines("infectabilityOfAgent, " + str(infectabilityOfAgent) + "\n")
    TextFile.writelines("maskProbability, " + str(maskProbability) + "\n")
    TextFile.writelines("moveRate, " + str(moveRate) + "\n")
    TextFile.close()

