import random
import numpy as np

class Field:

    #count: how many agents are on the field
    #type: #inside or outside
    #listAgent: the list of agents who are on the field
    def __init__(self, type, count, listAgent):
        self.type = type
        self.count = count
        self.listAgent = listAgent


    def __repr__(self):
        return str(self.count)

    def printAgents(self):
        res = ""
        for x in self.listAgent:
            res = res + x.idAgent + ", "
        return res