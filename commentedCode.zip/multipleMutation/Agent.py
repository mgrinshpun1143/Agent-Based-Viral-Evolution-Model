import random
import numpy as np
from Field import Field

class Agent:

    #idAgent: each agent gets an ID
    #location/startlocation: position on the world as list [n,m]
    #moveRate: a probability if the agent will move in the step or not
    #status: can be susceptible, infected or removed
    #daysInStatus: how many days he is already in the status
    #infectability: how high the probability is that the agent get infected
    #mask: can be mask or noMask
    #span: how many field the agent can move from his startlocation
    #virusTyp = 0 not infected; numbers from 1 to 10 is a mutation
    #virusTypeRate: how high the probability is to infect other person
    def __init__(self, idAgent,location, moveRate, status, daysInStatus, infectability, startLocation, mask, span, virusType, virusTypesRate): #carefulness, color, moverate depends on carefulness
        self.idAgent = idAgent
        self.location = location
        self.moveRate = moveRate
        self.status = status
        self.daysInStatus = daysInStatus
        self.infectability = infectability
        self.startLocation = startLocation
        self.mask = mask
        self.span = span
        self.virusType = virusType
        self.virusTypesRate = virusTypesRate

    def __repr__(self):
        res = self.idAgent + ", status: " + self.status + ", with type:" + str(self.virusType) + " since: " + str(self.daysInStatus) + ", loc: [" + str(self.location[0])+ "," + str(self.location[1]) + "]"
        return(res)

